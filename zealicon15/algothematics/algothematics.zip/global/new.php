<?php
	session_start();
	$_SESSION['current']=".content";
?>