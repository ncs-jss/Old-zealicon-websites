<div class="nav_menu">
	<img src="assets/img/z/z_red.png" onclick="window.location='index.php'" id="mlogo"> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
	<a href="#" id="menu-icon"></a>
	<ul>
		<li onclick="window.location='home.php'" id="lhome">Home</li>
		<li onclick="window.location='elist.php'" id="levent">Events</li>
		<li onclick="window.location='gallery.php'" id="lgallery">Gallery</li>
		<li onclick="window.location='signin.php'" id="llogin">Login</li>
		<li onclick="window.location='signup.php'" id="lregister">Register</li>
		<li	onclick="window.location='team.php'" id="lteam">Team</li>
	</ul>
</div>