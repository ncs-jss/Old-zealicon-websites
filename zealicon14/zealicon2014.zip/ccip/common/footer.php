<div class="footer style-2">
            	<div class="background" > <div class="stitch"> </div> </div>
                <div class="foot-nav-bg"> </div>
            	<div class="content">
                    <div class="patch"> </div>
                    <div class="blur"> </div>
                    <div class="pattern">
                        <div class="container">
                        	
                            <div class="sixteen columns">
                                <div class="first column">
									
                                        <h4>CCIP - 2015</h4>
                                        <p>
                                            The CCIP 2015 is the first international conference on cognitive computing and information processing domain being held in India.
                     					</p>
                                        <p class="extra">
                                            This conference is being held in JSS Academy Of Technical Education , Noida , Uttar Pradesh.
                                        </p>
                                    
                                </div>
                                <div class="column ct">
                                    <h4>Important Links</h4>
									<p><div class="logo" style="text-align:center;">
                                <a href="index.php"><img src="images/content/jss_top.png" /></a><!-- Large Logo -->
                            <a href="http://www.jssaten.ac.in"><br/><br/>JSS Academy Of Technical Education, Noida</a></p>
                                </div>
                                </div>
                                <div class="last column omega">
                                    
                                    <h4>Stay in Touch</h4><br/><br/>
                                    <ul class="sm foot footicons">
                                        <li class="facebook"><a href="#facebook">Facebook</a></li>
                                        <li class="twitter"><a href="#twitter">LinkedIn</a></li>
                                        <li class="linkedin"><a href="#linkedin">Pinterest</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>