<div class="header-image" id="main_header">
				</br> </br>
				<font class="header-sub"> International Conference on </font> </br>
				<font class="header-sub"> Cognitive Computing and Information Processing  </font> </br>
				<font class="header-main"> CCIP - 2015 (2 - 4 Mar 2015)  </font> </br>
				</br> </br>
				<font class="header-det"> JSS Academy Of Technical Education, Noida </font>
</div>