<?php
	session_start();
?>
<html class=bg>
<head>
<title>
	Errata : Home
</title>

	<link rel="stylesheet" type="text/css" href="css/base.css"/>
</head>
	<body>
	<div class="header">
		<div class="imgt"> </div><div class="hdng">ERRATA - The Treasure Hunt</div>
	</div>
			<div class="main">
				<div class="part-1">
				<?php
					include_once('code/sidebar.php');
				?>
				</div>
				<div class="part-2"><font size="6rem" style="font-weight:bold;">Errata</font><br/>
			<p>Errata is offline now... We appreciate your keen participation in the event.... </p>
</br> </br> The Winners for this year's Errata are: </br>

1. Anvita Shukla (Level 11)</br>
2. Shikhar Srivastava (Level 10)</br> </br>
Congratulations....
			</div>
				
			</div>
				
			
			
			<br/><br/><br/>
			
	</body>
</html>