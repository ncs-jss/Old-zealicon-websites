<html class=bg>
<head>
	<title>
		Algothematics 
	</title>
	<link rel="stylesheet" type="text/css" href="css/base.css"/>
	
</head>
	<body>
	<div class="header">
		<div class="imgt"> <img id="toplogo" src="img/z_blood.png" style="max-width:200px;max-height:200px;"/> </div><div class="hdng">Algothematics - The Mathematical Insight</div>
	</div>
			<div class="main">
				<div class="part-1">
				<?php
					session_start();
					include_once('code/sidebar.php');
				?>
				</div>
				<div class="part-2"><font size="6rem" style="font-weight:bold;">Algothematics</font><br/>
			<p>Algothematics is offline now... </br>
			</br>
			The winners for the event... </br></br>
			1. Shiv Pratap Singh (Level 5)</br>
			2. Ankur Rana (Level 4)</br></br>
			Congratulations.</p>
			</div>
				
			</div>
				
			
			
			<br/><br/><br/>
			
	</body>
</html>
