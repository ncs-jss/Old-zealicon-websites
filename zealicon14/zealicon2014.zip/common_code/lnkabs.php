<?php
    $ROOT_FILE_PATH = $_SERVER['DOCUMENT_ROOT'];
	$ROOT_PATH ="http://";
	$ROOT_PATH .= $_SERVER['SERVER_NAME'];
?>