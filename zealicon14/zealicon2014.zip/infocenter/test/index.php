<?php
	$rfrom=$_COOKIE['redirected_from'];
	echo "$rfrom";
?>