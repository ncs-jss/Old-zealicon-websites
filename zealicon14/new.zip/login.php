<?php
	session_start();
	if(isset($_SESSION['user']))
	{
		if(isset($_SESSION['page']))
		header('Location:'.$_SESSION['page'].'.php');
		else
		header('Location:code/logout.php');
	}
?>

<html class=bg>
<head>
	<title>
		Algothematics : Login
	</title>
	<link rel="stylesheet" type="text/css" href="css/base.css"/>
</head>
	<body>
	<div class="header">
		<div class="imgt"><img src="img/z_blood.png" style="max-width:200px;max-height:200px;"/></div><div class="hdng">Algothematics - The Mathematical Insight</div>
	</div>
			<div class="main">
				<div class="Part-1">
				<?php
					require('code/sidebar.php');
				?>
				</div>
				<div class="part-2"><font size="6rem" style="font-weight:bold;">Login</font><br/>
				
				<form action="code/login.php" method="post">
				<br/><table align=center style="width:400px; margin-left:200px;height:100px; ">
				<tr><td></td><td></td><td>
				<?php
					if(isset($_SESSION['error']))
					{
					echo "<font color=red> ".$_SESSION['error']."</font>";
					unset($_SESSION['error']);
					}
				?>
				</td></tr>
				<tr>
				<td>Email </td><td>:</td>
				<td><input type="email" name="email"></td>
				</tr>
				<tr>
				<td>Password </td><td>:</td>
				<td><input type="password" name="pass"></td>
				</tr>
				<tr><td></td><td></td>
				<td><input class="button small" type="submit" value="Login" style=""></td>
				</tr>
				</table>
				</form>
			</div>
				
			</div>
				
			
			
			<br><br><br>
			
	</body>

</html>