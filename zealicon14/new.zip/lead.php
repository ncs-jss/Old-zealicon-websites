<?php
	session_start();

?>
<html class=bg>
<head>
	<title>
		Algothematics : Leaderboard
	</title>
	<link rel="stylesheet" type="text/css" href="css/base.css"/>
</head>
	<body>
		<div class="header">
		<div class="imgt"><img src="img/z_blood.png" style="max-width:200px;max-height:200px;"/></div><div class="hdng">Algothematics - The Mathematical Insight</div>
	</div>
		
		<div class="main">
			<div class="part-1">
			<?php
				require_once('code/sidebar.php');
			?>
		</div>
		<div class="part-2"><font size="6rem" style="font-weight:bold;margin-left:200px;text-align:center;">Leaderboard</font><br/>
		<table  align="center"style="color:white;text-align:center;" cellspacing="5">
			<th>S No.</th>
			<th>Name</th>
			<th>Level</th>
			<th>College</th>
			<?php
				require_once('code/dbcon.php');
				$sql="SELECT fname, lname,college, level FROM persons ORDER BY Level DESC, timestmp ASC LIMIT 0,10";
				$res=mysqli_query($con, $sql);
				$i=1;
				while($ans=mysqli_fetch_array($res))
					{
						echo "<tr>";
						echo "<td>";
						echo $i;
						$i++;
						echo "</td>";
						echo "<td>";
						echo $ans['fname'];
						echo " ";
						echo $ans['lname'];
						echo "</td>";
						echo "<td>";
						echo $ans['level'];
						echo "</td>";
						echo "<td>";
						echo $ans['college'];
						echo "</td>";
						echo "</tr>";
					}
			?>
		</table>
		</div>
		</div>
	</body>
