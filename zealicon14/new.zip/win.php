<?php
					session_start();
					
					if(!isset($_SESSION['user']))
	{
		$_SESSION['error']="Login then play";
		header('Location:login.php');
	}
	else
	{
		if($_SESSION['level']!=16)
		header('Location:'.$_SESSION['page'].'.php');
	}
				?>
<html class=bg>
<head>
	<title>
		Algothematics : Win
	</title>
	<link rel="stylesheet" type="text/css" href="css/base.css"/>
</head>
	<body>
	<div class="header">
		<div class="imgt"><img src="img/z_blood.png" style="max-width:200px;max-height:200px;"/></div><div class="hdng">Algothematics - The Mathematical Insight</div>
	</div>
			
			<div class="main">
				<div class="Part-1">
				<?php
					include_once('code/sidebar.php');
					flush();
					if($_SESSION['level']!=16)
					header('Location:'.$_SESSION['page'].'.php');
				?>
	

				</div>
				<div class="Part-2">
					<font style="font-size:4rem;">Congratulations .... You won the event.....!!</font>
				</div>
			</div>
				
			
			
			<br/><br/><br/>
			
	</body>
</html>