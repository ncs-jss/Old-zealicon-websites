<html class=bg>
<head>
	<title>
		Algothematics 
	</title>
	<link rel="stylesheet" type="text/css" href="css/base.css"/>
	
</head>
	<body>
	<div class="header">
		<div class="imgt"> <img id="toplogo" src="img/z_blood.png" style="max-width:200px;max-height:200px;"/> </div><div class="hdng">Algothematics - The Mathematical Insight</div>
	</div>
			<div class="main">
				<div class="part-1">
				<?php
					session_start();
					include_once('code/sidebar.php');
				?>
				</div>
				<div class="part-2"><font size="6rem" style="font-weight:bold;">Algothematics</font><br/>
			<p>�Mathematics is the language which God has written in the universe.�
						-Anonymous<br/>
				Algorithm design is the mother of all Computer Science fields. Zealicon pays a tribute to this captivating branch of study by organizing Algothematics.
				Algothematics is an online problem solving completion which not just requires programming skill but an indispensable Mathematical insight. It is an engaging 24 hour event in which a candidate must answer by providing the precise numerical solution to the given problem</p>
			</div>
				
			</div>
				
			
			
			<br/><br/><br/>
			
	</body>
</html>