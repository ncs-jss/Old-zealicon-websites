<html class=bg>
<head>
	<title>
		Algothematics : Rules
	</title>
	<link rel="stylesheet" type="text/css" href="css/base.css"/>
</head>
	<body>
	<div class="header">
		<div class="imgt"> <img id="toplogo" src="img/z_blood.png" style="max-width:200px;max-height:200px;"/> </div><div class="hdng">Algothematics - The Mathematical Insight</div>
	</div>
			<div class="main">
				<div class="part-1">
				<?php
					include_once('code/sidebar.php');
				?>
				</div>
				<div class="part-2"><font size="6rem" style="font-weight:bold;">Rules</font><br/>
				<ol>
					<li>	It is an individual event.</li>
					<li>	Candidates are requested not to use an alias while registering for this event.</li>
					<li>	A Forum would be set up in Facebook to encourage discussions during the event</li>

				</ol>
			
			</div>
				
			</div>
				
			
			
			<br/><br/><br/>
			
	</body>
</html>