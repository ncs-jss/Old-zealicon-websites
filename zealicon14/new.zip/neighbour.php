<?php
	session_start();
	if(!isset($_SESSION['user']))
	{
		$_SESSION['error']="Login then play";
		header('Location:login.php');
	}
	else
	{
		if($_SESSION['level']!=12)
		header('Location:'.$_SESSION['page'].'.php');
	}
?>
<html class=bg>
<head>
	<title>
		Algothematics : quest
	</title>
	<link rel="stylesheet" type="text/css" href="css/base.css"/>
</head>
	<body>
	<div class="header">
		<div class="imgt"><img src="img/z_blood.png" style="max-width:200px;max-height:200px;"/></div><div class="hdng">Algothematics - The Mathematical Insight</div>
	</div>
			
			<div class="main">
				<div class="Part-1">
				<?php
					include_once('code/sidebar.php');
				flush();
					if($_SESSION['level']!=12)
					header('Location:'.$_SESSION['page'].'.php');
				?>
	

				</div>
				<div class="Part-2">
					<form id="input" action="code/check.php" method="post">
					<table style="text-align:center;">
					<tr>
						<td>
						<?php
							$q=new que;
							$q->get($con);
							class que
							{
								public function get($con)
								{
										$l=stripslashes($_SESSION['level']);
										$sql="SELECT * FROM `list` WHERE `level` = '12'";
										$res=mysqli_query($con,$sql);
										if($res)
										{
											$questionDetails= mysqli_fetch_assoc($res);
											$ques= $questionDetails['question'];
											
												echo "<div class='ques'>".$ques."</div>";
										}
										else
										echo("Connection Problem....");
			
								}
							}
							mysqli_close($con);
						?>
						</td>		
					</tr>
					<tr>
						<td>
						<input type="text" name="ans"><br><br>
						</td>
					</tr>
					<tr>
						<td>	
						<input class="button small" type="submit" value="Done" name="submission">
						</td>
					</tr>
					</form>
				</div>
			</div>
				
			
			
			<br/><br/><br/>
			
	</body>
</html>